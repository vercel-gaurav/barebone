import { Roboto_Slab } from 'next/font/google';
import React from 'react';

import Navlink from '../common/nav-link';

const font = Roboto_Slab({ weight: ['400', '700'], subsets: ['cyrillic'] });

export default function Navbar() {
	return (
		<nav className="flex w-full justify-center p-3">
			<div className="flex w-full max-w-7xl justify-between">
				<div>
					<Navlink name="G." link="/" />
				</div>

				<ul className="flex">
					{[
						{ name: 'Home', link: '/' },
						{ name: 'About', link: '/about' },
						{ name: 'Contact', link: '/contact' },
					].map(({ name, link }) => {
						return <Navlink {...{ name, link }} />;
					})}
				</ul>
			</div>
		</nav>
	);
}
