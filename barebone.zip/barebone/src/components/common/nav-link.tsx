import { ClassValue } from 'clsx';
import { Roboto_Slab } from 'next/font/google';
import React from 'react';

const font = Roboto_Slab({ weight: ['400', '700'], subsets: ['cyrillic'] });

const Navlink = ({
	link,
	name,
	className,
}: {
	name: string;
	link: string;
	className?: ClassValue;
}) => {
	return (
		<div className={'p-2 ' + font.className + ' ' + className}>
			<a className="text-4xl font-bold" href={link}>
				{name}
			</a>
		</div>
	);
};

export default Navlink;
