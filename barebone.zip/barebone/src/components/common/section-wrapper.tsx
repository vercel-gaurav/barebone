import clsx, { type ClassValue } from 'clsx';
import React, { type ReactNode } from 'react';

export default function SectionWrapper({
	children,
	className,
}: {
	children: ReactNode;
	className?: ClassValue;
}) {
	return <section className={clsx('w-full', className)}>{children}</section>;
}
