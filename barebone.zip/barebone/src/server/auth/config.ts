import { NextAuthConfig } from 'next-auth';
import Google from 'next-auth/providers/google';

export default {
	pages: {
		newUser: '/onboarding',
	},
	providers: [Google],
} satisfies NextAuthConfig;
