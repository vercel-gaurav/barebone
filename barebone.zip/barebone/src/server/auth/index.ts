import { PrismaAdapter } from '@auth/prisma-adapter';
import NextAuth from 'next-auth';
import Resend from 'next-auth/providers/resend';

import { prisma } from '@core/prisma';

import authConfig from '@server/auth/config';

const combinedProviders = [
	...authConfig.providers,
	Resend({
		from: 'accounts@codebug.in',
	}),
];

export const { handlers, auth, signIn, signOut } = NextAuth({
	adapter: PrismaAdapter(prisma),
	session: { strategy: 'jwt' },
	providers: combinedProviders,
});
