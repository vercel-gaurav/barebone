import NextAuth from 'next-auth';
import { type MiddlewareConfig } from 'next/server';

import authConfig from '@server/auth/config';

import {
	DEFAULT_LOGIN_REDIRECT,
	apiAuthPrefix,
	getAuthRoutes,
	getPublicRoutes,
} from '@lib/routes';

const { auth } = NextAuth(authConfig);

export default auth(async (req) => {
	const { nextUrl } = req;
	const isLoggedIn = !!req.auth;

	const publicRoutes = await getPublicRoutes();
	const authRoutes = await getAuthRoutes();

	const isApiAuthRoute = nextUrl.pathname.startsWith(apiAuthPrefix);
	const isPublicRoute = publicRoutes.includes(nextUrl.pathname);
	const isAuthRoute = authRoutes.includes(nextUrl.pathname);

	if (isApiAuthRoute) return;

	if (isAuthRoute) {
		if (isLoggedIn) {
			return Response.redirect(new URL(DEFAULT_LOGIN_REDIRECT, nextUrl));
		}
		return;
	}

	if (!isLoggedIn && !isPublicRoute) {
		return Response.redirect(new URL('/signin', nextUrl));
	}

	return;
});

export const config: MiddlewareConfig = {
	matcher: ['/((?!.+\\.[\\w]+$|_next).*)', '/(api|trpc)(.*)'],
};
