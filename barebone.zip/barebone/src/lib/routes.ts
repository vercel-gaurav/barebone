import { kv } from '@vercel/kv';

/**
 * List of routes that are accessible to public.
 * These routes do not require authentication.
 * @returns {Promise<string[]>}
 */
export const getPublicRoutes = async () => {
	const routes = await kv.get('publicRoutes');

	if (typeof routes === 'string') {
		return JSON.parse(routes);
	}

	if (typeof routes === 'object') {
		return routes ?? [];
	}

	return [];
};

/**
 * List of routes that are used for user authentication.
 * These routes will redirect users to protected pages.
 * @returns {Promise<string[]>}
 */
export const getAuthRoutes = async () => {
	const routes = await kv.get('authRoutes');

	if (typeof routes === 'string') {
		return JSON.parse(routes);
	}

	if (typeof routes === 'object') {
		return routes ?? [];
	}

	return [];
};

/**
 * The prefix for authentication api routes.
 * Routes starting with this prefix are used for authentication.
 */
export const apiAuthPrefix = '/api/auth';

/**
 * The default route to redirect users to after login.
 */
export const DEFAULT_LOGIN_REDIRECT = '/home';
