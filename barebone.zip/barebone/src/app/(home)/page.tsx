import SectionWrapper from '@components/common/section-wrapper';
import Navbar from '@components/home/navbar';

export default function Home() {
	return (
		<>
			<Navbar />
			<div className="flex min-h-screen flex-col items-center justify-between p-24">
				<h1>This is the main page</h1>
			</div>
		</>
	);
}
