import { auth, signOut } from "@server/auth";
import React from "react";

export default async function Page() {
	const session = await auth();
	return (
		<div>
            <h1 className="text-3xl font-bold">This is the onboarding page</h1>
			{session?.user ? <h1>Signed In</h1> : <h1>Not Signed In</h1>}
			<p>Session: {JSON.stringify(session, null, 2)}</p>
			{session?.user && (
				<form
					action={async (formData) => {
						"use server";
						await signOut();
					}}
				>
					<button type="submit">Sign out</button>
				</form>
			)}
		</div>
	);
}
